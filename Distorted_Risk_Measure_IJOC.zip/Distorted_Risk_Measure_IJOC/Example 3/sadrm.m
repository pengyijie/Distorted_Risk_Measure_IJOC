function D=sadrm(d,num,a,b,mu1,mu2,sigma1,sigma2,rho)
%tic
D=0;
X1=normrnd(0,1,1,num);
X2=normrnd(0,1,1,num);
X3=normrnd(0,1,1,num);
Z1=mu1+sigma1*rho^(1/2)*X1+sigma1*(1-rho)^(1/2)*X2;
Z2=mu2+sigma2*rho^(1/2)*X1+sigma2*(1-rho)^(1/2)*X3;
Y1=exp(Z1);
Y2=exp(Z2);
Y=Y1+Y2;
q=sort(Y);
p1=mean((Y<a));
p2=mean((Y<b));
it=fix((p2-p1)/d);
%E=zeros(1,it);
x=p1+d*((1:it+1)-1);
I=fix(x(2:end)*num);
q=q(I);
w=df2(x);
%w=df3(x,0);
for i=1:it
%E=ste(q(i),X1,X2,X3,Y1,Y,sigma1,rho);
E=ste2(q(i),X1,X2,X3,Y,Y1,Y2,mu1,sigma1,sigma2,rho);
D=D-E*(w(i+1)-w(i));
end
%toc
end