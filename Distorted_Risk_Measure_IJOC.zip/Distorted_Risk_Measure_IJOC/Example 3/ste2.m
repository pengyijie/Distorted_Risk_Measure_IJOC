function E=ste2(q,X1,X2,X3,Y,Y1,Y2,mu1,sigma1,sigma2,rho)
%A=(-X2-sigma1*(1-rho)^(1/2));
%W1=A./Y1/sigma1/(1-rho)^(1/2);
%B1=sigma1*(X1/(rho)^(1/2)-X2/(1-rho)^(1/2))/2;
%B2=sigma2*(X1/(rho)^(1/2)-X3/(1-rho)^(1/2))/2;
%W2=-B1-(B1+B2.*Y2./Y1).*A/sigma1/(1-rho)^(1/2);
Y3=Y1*exp(-sigma1^2)+Y2*exp(-sigma1*sigma2*rho);
C1=rho^(1/2)*X1+(1-rho)^(1/2)*X2;
C2=rho^(1/2)*X1+(1-rho)^(1/2)*X3;
W1=-(C1-rho*C2)*exp(-mu1+sigma1^2/2)/sigma1/(1-rho^2);
W2=(rho-rho*(C1.^2+C2.^2-2*rho*C1.*C2)/(1-rho^2)+C1.*C2)/(1-rho^2);
F=mean((Y<q).*W2);
f=mean((Y3<q).*W1);
E=-F/f;
end