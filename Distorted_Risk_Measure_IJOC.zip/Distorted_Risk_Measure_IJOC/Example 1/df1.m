function w=df1(x,o)
x=1-x;
a=0.1;
if o==0
w=normcdf(norminv(x,0,1)+a);
else
w=exp(-a*norminv(x,0,1)-a^2/2);
end
end