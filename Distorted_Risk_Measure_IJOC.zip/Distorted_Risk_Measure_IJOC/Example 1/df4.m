function w=df4(x,o)
x=1-x;
a=0.5;
if o==0
w=x.^a;
else
w=a*x.^(a-1);
end
end