function E=ste2(q,n,s0,sigma,delta,k,h,X,G,I,F)
q=q+k;
I1=(G<log(q));
I2=(log(h)<G)+I1;
F=F+I.*I2.*X(:,1)/sigma/s0/(delta)^(1/2);
f=-I.*I1.*X(:,n)/sigma/q/(delta)^(1/2);
E=mean(F)./mean(f);
end