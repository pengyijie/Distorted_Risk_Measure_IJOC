function D=multires
tic
it=100;
D=zeros(1,it);
n=5;
s0=100;
r=0;
sigma=0.1;
T=1;
k=95;
h=105;
d=10^(-3);
num=10^8;
p=0.01;
for i=1:it
  D(i)=fdc(n,s0,r,sigma,T,k,h,d,num,p);
%  D(i)=fd(n,s0,r,sigma,T,k,h,d,num,p);
 % D(i)=ipa(10^(-3),1,1/2,2,10^6);
% D(i)=sadrm(n,s0,r,sigma,T,k,h,d,num);
% D(i)=test4(n,s0,r,sigma,T,k,h,d,0.01,num);
%D(i)=test3(n,s0,r,sigma,T,k,h,d,num);
end
%save('fd3_4_2','D','n','s0','r','sigma','T','k','h','d','num')
toc
end