function [X,G,I,I1,F]=ste1(n,s0,r,sigma,delta,k,h,num)
X=normrnd(0,1,num,n);
Y=zeros(num,1);
I=ones(num,1);
F=zeros(num,1);
for i=1:n
if i<n
Y=Y+X(:,i);
G=log(s0)+i*(r-sigma^2/2)*delta+sigma*(delta)^(1/2)*Y;
I1=(G<log(h));
F=F+I.*(1-I1).*X(:,1)/sigma/s0/(delta)^(1/2);
I=I.*I1;
else
Y=Y+X(:,i);
G=log(s0)+i*(r-sigma^2/2)*delta+sigma*(delta)^(1/2)*Y;
I1=(log(k)<G).*(G<log(h));
end
end
end