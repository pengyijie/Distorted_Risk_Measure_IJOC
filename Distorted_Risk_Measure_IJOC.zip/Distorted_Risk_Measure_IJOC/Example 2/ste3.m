function [D1,E]=ste3(x,s0,sigma,delta,k,h,X,G,I,F)
I1=(G<log(x+k));
I2=(log(h)<G)+I1;
F=F+I.*I2.*X(:,1)/sigma/s0/(delta)^(1/2);
Ind=I.*I2+1-I;
%f=-I.*I1.*X(:,n)/sigma/(x+k)/(delta)^(1/2);
D1=mean(F);
E=mean(Ind);
%D2=mean(f);
end 